import * as core from "@idlizer/core";
import { Config } from "../general/Config.js";
import { Typechecker } from "../general/Typechecker.js";
import { ExtraParameter } from "../options/ExtraParameters.js";
export declare class CommonGenerator {
    static resolveProperty(property: ExtraParameter, iface: core.IDLInterface, typechecker: Typechecker): [core.IDLMethod | core.IDLProperty, core.IDLMethod | core.IDLProperty];
    static makeExtraParameter(param: ExtraParameter, iface: core.IDLInterface, typechecker: Typechecker): core.IDLParameter;
    static makeExtraParameters(iface: core.IDLInterface, config: Config, typechecker: Typechecker): core.IDLParameter[];
    static makeExtraStatement(prop: ExtraParameter, methods: [core.IDLMethod | core.IDLProperty, core.IDLMethod | core.IDLProperty], varNames: [string, string], writer: core.TSLanguageWriter): core.LanguageStatement;
}
//# sourceMappingURL=Generator.d.ts.map