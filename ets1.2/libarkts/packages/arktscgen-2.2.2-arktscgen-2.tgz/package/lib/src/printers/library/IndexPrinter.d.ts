import { IDLFile, IDLInterface } from "@idlizer/core";
import { SingleFilePrinter } from "../SingleFilePrinter.js";
import { Config } from "../../general/Config.js";
export declare class IndexPrinter extends SingleFilePrinter {
    private config;
    constructor(config: Config, idl: IDLFile);
    protected writer: import("@idlizer/core").TSLanguageWriter;
    protected filterInterface(node: IDLInterface): boolean;
    printInterface(node: IDLInterface): void;
}
//# sourceMappingURL=IndexPrinter.d.ts.map