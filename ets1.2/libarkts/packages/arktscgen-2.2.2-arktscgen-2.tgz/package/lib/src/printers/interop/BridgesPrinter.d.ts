import { CppLanguageWriter, IDLMethod, NamedMethodSignature } from "@idlizer/core";
import { IDLFile, IDLInterface, IDLType } from "@idlizer/core/idl";
import { InteropPrinter } from "./InteropPrinter.js";
import { Config } from "../../general/Config.js";
import { BaseTypeConvertor } from "../../type-convertors/BaseTypeConvertor.js";
export declare class BridgesPrinter extends InteropPrinter {
    private config;
    constructor(config: Config, file: IDLFile);
    private castTypeConvertor;
    private nativeTypeConvertor;
    private returnTypeConvertor;
    private interopMacroConvertor;
    protected writer: CppLanguageWriter;
    protected printMethod(iface: IDLInterface, node: IDLMethod): void;
    private printInteropMacro;
    static makeFunctionDeclaration(iface: IDLInterface, node: IDLMethod, converter: BaseTypeConvertor<IDLType>): [string, NamedMethodSignature];
    private printBody;
    private makeReturnExpression;
    private maybeDropConst;
}
//# sourceMappingURL=BridgesPrinter.d.ts.map