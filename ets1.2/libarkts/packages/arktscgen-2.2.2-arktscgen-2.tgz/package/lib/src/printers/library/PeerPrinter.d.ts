import { IDLInterface, IDLMethod, TSLanguageWriter } from "@idlizer/core";
import { Importer } from "./Importer.js";
import { Typechecker } from "../../general/Typechecker.js";
import { Config } from "../../general/Config.js";
export declare class PeerPrinter {
    private config;
    private typechecker;
    private importer;
    private bindingParameterTypeConvertor;
    constructor(config: Config, typechecker: Typechecker, // = new Typechecker(this.idl)
    importer: Importer);
    printInterface(iface: IDLInterface, writer: TSLanguageWriter): void;
    private printPeer;
    private printBody;
    private printConstructor;
    private printTypeGuard;
    private printMethods;
    private printFragment;
    private printGetter;
    printFunction(iface: IDLInterface, node: IDLMethod, writer: TSLanguageWriter): void;
    private printRegular;
    private makeStaticBindingCall;
    private makePeerBindingCall;
    private makeReturnBindingCall;
    private wrapBindingCall;
    private makeNativeObjectFactory;
    private printCreateOrUpdate;
    private makeBindingArguments;
    private makeOptional;
    private isNullable;
    private printAddToNodeMap;
    private printBrand;
}
//# sourceMappingURL=PeerPrinter.d.ts.map