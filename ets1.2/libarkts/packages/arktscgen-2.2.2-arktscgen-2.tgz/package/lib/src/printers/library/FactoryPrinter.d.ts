import { IDLFile, IDLInterface, TSLanguageWriter } from "@idlizer/core";
import { SingleFilePrinter } from "../SingleFilePrinter.js";
import { Importer } from "./Importer.js";
import { LibraryTypeConvertor } from "../../type-convertors/top-level/LibraryTypeConvertor.js";
import { Config } from "../../general/Config.js";
export declare class FactoryPrinter extends SingleFilePrinter {
    private config;
    protected importer: Importer;
    protected converter: LibraryTypeConvertor;
    protected writer: TSLanguageWriter;
    constructor(config: Config, idl: IDLFile);
    prologue(): void;
    epilogue(): void;
    protected filterInterface(node: IDLInterface): boolean;
    printInterface(node: IDLInterface): void;
    private printCreate;
    private printUpdate;
    private gettersForParams;
}
//# sourceMappingURL=FactoryPrinter.d.ts.map