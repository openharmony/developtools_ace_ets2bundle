import { MultiFilePrinter, MultiFileOutput } from "../MultiFilePrinter.js";
import { IDLFile, IDLInterface, IDLNamespace } from "@idlizer/core";
import { Config } from "../../general/Config.js";
export declare class AllPeersPrinter extends MultiFilePrinter {
    private config;
    private static FlattenNamespaces;
    private typechecker;
    constructor(config: Config, idl: IDLFile);
    protected filterInterface(node: IDLInterface): boolean;
    printNamespace(ns: IDLNamespace): MultiFileOutput[];
    printInterface(iface: IDLInterface): MultiFileOutput;
    private printFile;
    print(): MultiFileOutput[];
    /**
     * Sort interfaces in order of inheritance.
     */
    sortInterfaces(ifaces: readonly IDLInterface[]): IDLInterface[];
    private makeWriter;
    private isAllowed;
    private isAllowedMethod;
    static printIndexFile(out: MultiFileOutput[], config: Config, idl: IDLFile): string;
}
//# sourceMappingURL=AllPeersPrinter.d.ts.map