import { IDLMethod, LanguageWriter } from "@idlizer/core";
import { IDLInterface, IDLNode } from "@idlizer/core/idl";
import { IDLFile } from "@idlizer/core";
import { Typechecker } from "../../general/Typechecker.js";
import { AbstractVisitor } from "../SingleFilePrinter.js";
export declare abstract class InteropPrinter extends AbstractVisitor {
    protected file: IDLFile;
    constructor(file: IDLFile);
    protected abstract writer: LanguageWriter;
    protected typechecker: Typechecker;
    print(): string;
    visit(node: IDLNode): void;
    visitInterface(node: IDLInterface): void;
    visitMethod(iface: IDLInterface, node: IDLMethod): void;
    protected printMethod(iface: IDLInterface, node: IDLMethod): void;
}
//# sourceMappingURL=InteropPrinter.d.ts.map