import { IDLFile } from "@idlizer/core";
export declare class VerifyVisitor {
    private idl;
    constructor(idl: IDLFile);
    private incorrectDeclarations;
    complain(): void;
    private verifyDeclaration;
}
//# sourceMappingURL=VerifyVisitor.d.ts.map