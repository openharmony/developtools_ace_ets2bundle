export declare class Importer {
    private dir;
    constructor(dir: string, self?: string);
    private writer;
    private seen;
    withPeerImport(name: string): string;
    private withPeerImport2;
    withEnumImport(it: string): string;
    withReexportImport(it: string): string;
    addSeen(it: string): void;
    private import;
    getOutput(): string[];
}
//# sourceMappingURL=Importer.d.ts.map