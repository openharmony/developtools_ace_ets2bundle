import { IDLMethod, TSLanguageWriter } from "@idlizer/core";
import { IDLInterface } from "@idlizer/core/idl";
import { IDLFile } from "@idlizer/core";
import { InteropPrinter } from "./InteropPrinter.js";
export declare class BindingsPrinter extends InteropPrinter {
    constructor(idl: IDLFile);
    writer: TSLanguageWriter;
    private convertor;
    private returnConvertor;
    printMethod(iface: IDLInterface, node: IDLMethod): void;
}
//# sourceMappingURL=BindingsPrinter.d.ts.map