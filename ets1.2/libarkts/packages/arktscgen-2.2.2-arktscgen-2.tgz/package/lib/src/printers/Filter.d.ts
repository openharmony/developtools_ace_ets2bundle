import * as core from "@idlizer/core";
import { Typechecker } from "../general/Typechecker.js";
export declare class Filter {
    static makeMethod(name: string, returnType: core.IDLType, parameters: core.IDLParameter[], modifiers: core.MethodModifier[], isNullable: (param: core.IDLParameter | core.IDLType) => boolean): core.Method;
    static makeOptionalType(param: core.IDLParameter | core.IDLType, isNullable: (param: core.IDLParameter | core.IDLType) => boolean): core.IDLType;
    static isNullableType(type: core.IDLType, typechecker: Typechecker): boolean;
    static filterMoreSpecific(methods: core.IDLMethod[]): core.IDLMethod[];
    static filterParameters(params: core.IDLParameter[]): core.IDLParameter[];
    static filterMethods(methods: core.IDLMethod[]): core.IDLMethod[];
    static isOptional(param: core.IDLParameter, typechecker: Typechecker): boolean;
    static isArrayLengthParam(param: core.IDLParameter): boolean;
    static findArrayLengthParam(parameters: readonly core.IDLParameter[], startIndex?: number): number;
    static removeArrayLengthParam(parameters: readonly core.IDLParameter[]): core.IDLParameter[];
    static removeContextParam(parameters: readonly core.IDLParameter[]): core.IDLParameter[];
}
//# sourceMappingURL=Filter.d.ts.map