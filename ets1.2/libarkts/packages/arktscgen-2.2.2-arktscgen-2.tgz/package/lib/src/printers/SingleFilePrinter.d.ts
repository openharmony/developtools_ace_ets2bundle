import { Typechecker } from "../general/Typechecker.js";
import { IDLEnum, IDLFile, IDLInterface, IDLNode, IDLTypedef } from "@idlizer/core";
import { LanguageWriter } from "@idlizer/core";
import { Importer } from "./library/Importer.js";
export declare abstract class AbstractVisitor {
    protected abstract visit(entry: IDLNode): void;
    visitChildren(entry: IDLNode): void;
}
export declare abstract class SingleFilePrinter extends AbstractVisitor {
    protected idl: IDLFile;
    constructor(idl: IDLFile);
    protected abstract printInterface(node: IDLInterface): void;
    protected abstract filterInterface(node: IDLInterface): boolean;
    protected printEnum(node: IDLEnum): void;
    protected printTypedef(node: IDLTypedef): void;
    visit(node: IDLNode): void;
    prologue(): void;
    epilogue(): void;
    protected typechecker: Typechecker;
    protected importer?: Importer;
    protected abstract writer: LanguageWriter;
    print(): string;
}
//# sourceMappingURL=SingleFilePrinter.d.ts.map