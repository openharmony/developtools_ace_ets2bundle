import { IDLFile, IDLInterface, IDLNode } from "@idlizer/core";
import { AbstractVisitor } from "./SingleFilePrinter.js";
export type MultiFileOutput = {
    exports: string[];
    fileName: string;
    output: string;
};
export declare abstract class MultiFilePrinter extends AbstractVisitor {
    protected idl: IDLFile;
    constructor(idl: IDLFile);
    protected output: MultiFileOutput[];
    protected abstract printInterface(node: IDLInterface): MultiFileOutput;
    protected abstract filterInterface(node: IDLInterface): boolean;
    visit(node: IDLNode): void;
    print(): MultiFileOutput[];
}
//# sourceMappingURL=MultiFilePrinter.d.ts.map