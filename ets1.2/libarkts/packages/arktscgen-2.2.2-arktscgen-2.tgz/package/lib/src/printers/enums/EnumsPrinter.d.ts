import { TSLanguageWriter } from "@idlizer/core";
import { IDLEnum, IDLInterface, IDLTypedef } from "@idlizer/core/idl";
import { SingleFilePrinter } from "../SingleFilePrinter.js";
import { LibraryTypeConvertor } from "../../type-convertors/top-level/LibraryTypeConvertor.js";
export declare class EnumsPrinter extends SingleFilePrinter {
    protected converter: LibraryTypeConvertor;
    protected writer: TSLanguageWriter;
    protected printInterface(node: IDLInterface): void;
    protected filterInterface(node: IDLInterface): boolean;
    printEnum(node: IDLEnum): void;
    printTypedef(node: IDLTypedef): void;
}
//# sourceMappingURL=EnumsPrinter.d.ts.map