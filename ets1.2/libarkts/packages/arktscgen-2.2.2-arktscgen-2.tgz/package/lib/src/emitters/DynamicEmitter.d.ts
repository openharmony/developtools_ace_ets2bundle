import { IDLFile } from "@idlizer/core";
import { Config } from "../general/Config.js";
export declare class DynamicEmitter {
    private outDir;
    private sdkDir;
    private file;
    private config;
    private shouldLog;
    constructor(outDir: string, sdkDir: string, file: IDLFile, config: Config, shouldLog: boolean);
    private readonly pandaSdkVersion;
    private readonly generatorVersion;
    private logDir;
    private logCount;
    private bridgesPrinter;
    private bindingsPrinter;
    private enumsPrinter;
    private indexPrinter;
    private peersPrinter;
    private factoryPrinter;
    emit(): void;
    private printPeers;
    private printInterop;
    private printFile;
    private printFiles;
    private readTemplate;
    private withLog;
    private cleanLogDir;
}
//# sourceMappingURL=DynamicEmitter.d.ts.map