import { IDLType } from "@idlizer/core";
import { Typechecker } from "../../../general/Typechecker.js";
import { BaseTypeConvertor } from "../../BaseTypeConvertor.js";
export declare class ReturnTypeConvertor extends BaseTypeConvertor<IDLType> {
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=ReturnTypeConvertor.d.ts.map