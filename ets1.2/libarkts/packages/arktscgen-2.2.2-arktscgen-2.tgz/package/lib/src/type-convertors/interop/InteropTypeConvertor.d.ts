import { IDLContainerType, IDLPrimitiveType } from "@idlizer/core";
import { BaseTypeConvertor } from "../BaseTypeConvertor.js";
import { Typechecker } from "../../general/Typechecker.js";
export declare abstract class InteropTypeConvertor extends BaseTypeConvertor<string> {
    protected constructor(typechecker: Typechecker, heirConversions: {
        sequence: (type: IDLContainerType) => string;
        string: (type: IDLPrimitiveType) => string;
    });
}
//# sourceMappingURL=InteropTypeConvertor.d.ts.map