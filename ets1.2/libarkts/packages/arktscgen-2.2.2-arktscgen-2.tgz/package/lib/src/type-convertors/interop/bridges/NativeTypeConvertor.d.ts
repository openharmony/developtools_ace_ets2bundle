import { InteropTypeConvertor } from "../InteropTypeConvertor.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare class NativeTypeConvertor extends InteropTypeConvertor {
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=NativeTypeConvertor.d.ts.map