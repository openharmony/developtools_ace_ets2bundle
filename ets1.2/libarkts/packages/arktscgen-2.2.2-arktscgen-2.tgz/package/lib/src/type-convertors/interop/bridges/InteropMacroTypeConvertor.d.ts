import { InteropTypeConvertor } from "../InteropTypeConvertor.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare class InteropMacroTypeConvertor extends InteropTypeConvertor {
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=InteropMacroTypeConvertor.d.ts.map