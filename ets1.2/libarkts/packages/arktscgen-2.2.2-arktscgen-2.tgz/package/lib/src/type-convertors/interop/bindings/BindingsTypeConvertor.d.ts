import { InteropTypeConvertor } from "../InteropTypeConvertor.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare class BindingsTypeConvertor extends InteropTypeConvertor {
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=BindingsTypeConvertor.d.ts.map