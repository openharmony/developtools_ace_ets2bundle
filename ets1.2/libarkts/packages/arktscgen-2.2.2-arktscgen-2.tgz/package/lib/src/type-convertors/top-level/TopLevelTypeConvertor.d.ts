import { BaseTypeConvertor } from "../BaseTypeConvertor.js";
import { IDLContainerType, IDLOptionalType, IDLPrimitiveType, IDLReferenceType } from "@idlizer/core";
import { Typechecker } from "../../general/Typechecker.js";
export declare abstract class TopLevelTypeConvertor<T> extends BaseTypeConvertor<T> {
    protected constructor(typechecker: Typechecker, heirConversions: {
        sequence: (type: IDLContainerType) => T;
        string: (type: IDLPrimitiveType) => T;
        enum: (type: IDLReferenceType) => T;
        reference: (type: IDLReferenceType) => T;
        optional: (type: IDLOptionalType) => T;
        number: (type: IDLPrimitiveType) => T;
        void: (type: IDLPrimitiveType) => T;
        pointer: (type: IDLPrimitiveType) => T;
        boolean: (type: IDLPrimitiveType) => T;
        undefined: (type: IDLPrimitiveType) => T;
    });
}
//# sourceMappingURL=TopLevelTypeConvertor.d.ts.map