import { IDLType } from "@idlizer/core";
import { Config } from "../../general/Config.js";
import { Importer } from "../../printers/library/Importer.js";
import { BaseTypeConvertor } from "../BaseTypeConvertor.js";
export declare function convertAndImport(importer: Importer, converter: BaseTypeConvertor<string>, type: IDLType, config: Config): string;
//# sourceMappingURL=ImporterTypeConvertor.d.ts.map