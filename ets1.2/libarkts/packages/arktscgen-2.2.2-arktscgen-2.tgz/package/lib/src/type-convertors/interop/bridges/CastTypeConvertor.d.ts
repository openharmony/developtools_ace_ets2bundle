import { Typechecker } from "../../../general/Typechecker.js";
import { BaseTypeConvertor } from "../../BaseTypeConvertor.js";
export declare class CastTypeConvertor extends BaseTypeConvertor<string> {
    private castToTypeConvertor;
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=CastTypeConvertor.d.ts.map