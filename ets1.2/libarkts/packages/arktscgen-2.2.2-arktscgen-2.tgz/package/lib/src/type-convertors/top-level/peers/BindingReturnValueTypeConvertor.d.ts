import { IDLType } from "@idlizer/core";
import { Importer } from "../../../printers/library/Importer.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare function unpackWrapper(type: IDLType, typechecker: Typechecker): string | undefined;
export declare function hasTypeHintArgument(wrapper: string): boolean;
export declare function typeHintArgument(type: IDLType, typechecker: Typechecker, importer: Importer): string | undefined;
export declare function hasFactoryArgument(wrapper: string): boolean;
//# sourceMappingURL=BindingReturnValueTypeConvertor.d.ts.map