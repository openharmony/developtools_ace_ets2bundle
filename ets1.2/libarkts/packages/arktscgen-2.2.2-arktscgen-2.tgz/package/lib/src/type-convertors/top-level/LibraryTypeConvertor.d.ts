import { IDLReferenceType } from "@idlizer/core";
import { TopLevelTypeConvertor } from "./TopLevelTypeConvertor.js";
import { Typechecker } from "../../general/Typechecker.js";
declare class _LibraryTypeConvertor extends TopLevelTypeConvertor<string> {
    constructor(typechecker: Typechecker);
}
export declare class LibraryTypeConvertor extends _LibraryTypeConvertor {
    protected fullQualified: boolean;
    constructor(typechecker: Typechecker, fullQualified?: boolean);
    convertTypeReference(type: IDLReferenceType): string;
}
export {};
//# sourceMappingURL=LibraryTypeConvertor.d.ts.map