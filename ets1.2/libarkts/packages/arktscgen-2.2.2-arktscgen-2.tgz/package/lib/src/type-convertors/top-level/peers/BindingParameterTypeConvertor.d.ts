import { TopLevelTypeConvertor } from "../TopLevelTypeConvertor.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare class BindingParameterTypeConvertor extends TopLevelTypeConvertor<(parameter: string) => string | string[]> {
    constructor(typechecker: Typechecker);
}
//# sourceMappingURL=BindingParameterTypeConvertor.d.ts.map