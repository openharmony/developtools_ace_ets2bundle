import { IDLContainerType, IDLImport, IDLOptionalType, IDLPrimitiveType, IDLReferenceType, IDLType, IDLTypeParameterType, IDLUnionType, TypeConvertor } from "@idlizer/core";
import { Typechecker } from "../general/Typechecker.js";
export declare abstract class BaseTypeConvertor<T> implements TypeConvertor<T> {
    typechecker: Typechecker;
    private conversions;
    protected constructor(typechecker: Typechecker, conversions: {
        sequence: (type: IDLContainerType) => T;
        enum: (type: IDLReferenceType) => T;
        reference: (type: IDLReferenceType) => T;
        optional: (type: IDLOptionalType) => T;
        i8: (type: IDLPrimitiveType) => T;
        iu8: (type: IDLPrimitiveType) => T;
        i16: (type: IDLPrimitiveType) => T;
        i32: (type: IDLPrimitiveType) => T;
        iu32: (type: IDLPrimitiveType) => T;
        i64: (type: IDLPrimitiveType) => T;
        iu64: (type: IDLPrimitiveType) => T;
        f32: (type: IDLPrimitiveType) => T;
        f64: (type: IDLPrimitiveType) => T;
        boolean: (type: IDLPrimitiveType) => T;
        string: (type: IDLPrimitiveType) => T;
        void: (type: IDLPrimitiveType) => T;
        pointer: (type: IDLPrimitiveType) => T;
        undefined: (type: IDLPrimitiveType) => T;
    });
    convertContainer(type: IDLContainerType): T;
    convertPrimitiveType(type: IDLPrimitiveType): T;
    convertTypeReferenceAsImport(type: IDLReferenceType, importClause: string): T;
    convertTypeReference(type: IDLReferenceType): T;
    convertOptional(type: IDLOptionalType): T;
    convertUnion(type: IDLUnionType): T;
    convertImport(type: IDLImport): T;
    convertTypeParameter(type: IDLTypeParameterType): T;
    convertType(type: IDLType): T;
}
//# sourceMappingURL=BaseTypeConvertor.d.ts.map