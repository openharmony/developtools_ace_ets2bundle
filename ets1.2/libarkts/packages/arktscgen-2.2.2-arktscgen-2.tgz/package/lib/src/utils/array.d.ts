export declare function withInserted<T>(array: T[], index: number, value: T): T[];
export declare function remove<T>(array: T[], value: T): void;
export declare function reversed<T>(array: T[]): T[];
//# sourceMappingURL=array.d.ts.map