export declare const DIR_NAME: string;
//# sourceMappingURL=utils.d.ts.map