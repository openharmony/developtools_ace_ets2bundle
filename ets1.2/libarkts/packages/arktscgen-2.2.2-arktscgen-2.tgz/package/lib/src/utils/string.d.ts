export declare function pascalToCamel(value: string): string;
export declare function dropPostfix(value: string, toDrop: string): string;
export declare function dropPrefix(value: string, toDrop: string): string;
//# sourceMappingURL=string.d.ts.map