export declare function isNumber(value: any): value is number;
export declare function id<T>(value: T): T;
//# sourceMappingURL=types.d.ts.map