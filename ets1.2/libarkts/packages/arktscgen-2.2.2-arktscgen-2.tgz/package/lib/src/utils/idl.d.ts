import { IDLContainerType, IDLExtendedAttribute, IDLInterface, IDLMethod, IDLNamedNode, IDLNode, IDLParameter, IDLPrimitiveType, IDLProperty, IDLReferenceType, IDLType, LanguageExpression, LanguageStatement, LanguageWriter, Method, MethodModifier, NamedMethodSignature, TSLanguageWriter } from "@idlizer/core";
import * as idl from "@idlizer/core";
export declare function isString(node: IDLType): node is IDLPrimitiveType;
export declare function isSequence(node: IDLType): node is IDLContainerType;
export declare function createUpdatedInterface(node: IDLInterface, methods?: IDLMethod[], name?: string, inheritance?: IDLReferenceType[], extendedAttributes?: IDLExtendedAttribute[], properties?: IDLProperty[]): idl.IDLInterface | idl.IDLNamespace;
export declare function baseName(type: IDLReferenceType): string;
export declare function baseNameString(name: string): string;
export declare function createUpdatedMethod(node: IDLMethod, name?: string, parameters?: IDLParameter[], returnType?: IDLType, extendedAttributes?: IDLExtendedAttribute[]): IDLMethod;
export declare function nodeType(node: IDLInterface): string | undefined;
export declare function nativeType(node: IDLInterface): string | undefined;
export declare function nodeNamespace(node: IDLNode): string | undefined;
/**
 * Returns a fully qualified name for a node with no exceptions.
 * @note Primarily used to pass a name to Config' options.
*/
export declare function fqName(node: IDLNamedNode): string;
export declare function dropNamespace(node: IDLInterface): void;
export declare function parent(node: IDLInterface): string | undefined;
export declare function createDefaultTypescriptWriter(): TSLanguageWriter;
export declare function signatureTypes(node: IDLMethod): IDLType[];
export declare function isIrNamespace(node: IDLInterface): boolean;
export declare function createSequence(inner: IDLType): IDLContainerType;
export declare function innerType(node: IDLContainerType): IDLType;
export declare function innerTypeIfContainer(node: IDLType): IDLType;
export declare function innerTypeCommon(type: IDLType): IDLType;
export declare function makeMethod(name: string, parameters: {
    name: string;
    type: IDLType;
    isOptional: boolean;
}[], returnType: IDLType, modifiers?: MethodModifier[]): Method;
export declare function makeSignature(parameters: {
    name: string;
    type: IDLType;
    isOptional?: boolean;
}[], returnType: IDLType): NamedMethodSignature;
export declare function makeExpression(writer: LanguageWriter, arg: string | LanguageExpression): LanguageExpression;
export declare function makeStatement(writer: LanguageWriter, arg: string | LanguageExpression | LanguageStatement): LanguageStatement;
export type ReferenceResolver = (ref: IDLReferenceType, pov?: IDLNode) => IDLNamedNode | undefined;
export declare function flatParentsImpl(ref: IDLReferenceType | IDLInterface, resolveReference: ReferenceResolver): IDLInterface[];
export declare function makePrettyName(name: string): string;
/**
 * A fully qualified name of a type that reference points to.
 * @note 'ir' namespace is ignored and treated as global namespace.
 */
export declare function makeFullyQualifiedName(ref: IDLNamedNode): string;
export declare function makeFullyQualifiedName(ref: IDLReferenceType, resolveReference: ReferenceResolver): string;
/**
 * If namespaces of the reference and resolved declaration
 * are the same, non-qualified name is returned. Otherwise, a fully qualified.
 * @note 'ir' namespace is ignored and treated as global namespace.
 */
export declare function makeEnoughQualifiedName(ref: IDLReferenceType, resolveReference: ReferenceResolver): string;
//# sourceMappingURL=idl.d.ts.map