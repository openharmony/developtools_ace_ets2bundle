type Method = {
    name: string;
    definition: string;
};
export declare class CodeFragmentOptions {
    constructor(filePath?: string);
    private readonly fragments;
    getCodeFragment(name: string): Method[] | undefined;
}
export {};
//# sourceMappingURL=CodeFragmentOptions.d.ts.map