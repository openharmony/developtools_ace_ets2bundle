type IParameter = {
    name: string;
    setter?: string;
    getter?: string;
    optional?: boolean;
};
export declare class ExtraParameter implements IParameter {
    private param;
    constructor(param: IParameter);
    get name(): string;
    get getter(): string | undefined;
    get setter(): string | undefined;
    get optional(): boolean;
}
export declare class ExtraParameters {
    constructor(filePath?: string);
    hasParameters(iface: string): boolean;
    getParameters(iface: string): ExtraParameter[];
    private readonly parameters;
}
export {};
//# sourceMappingURL=ExtraParameters.d.ts.map