export declare class IgnoreOptions {
    constructor(filePath?: string);
    private readonly peers;
    private readonly partial;
    hasReexportReplacement(name: string): boolean;
    isIgnoredPeer(name: string): boolean;
    isIgnoredMethod(iface: string, method: string): boolean;
    isIgnoredProperty(iface: string, name: string): boolean;
    isIgnoredInterface(name: string, namespace?: string): boolean;
    private ignored;
}
export declare class IrHackOptions {
    private readonly irHack;
    constructor(filePath?: string);
    isIrHackInterface(name: string): boolean;
}
//# sourceMappingURL=IgnoreOptions.d.ts.map