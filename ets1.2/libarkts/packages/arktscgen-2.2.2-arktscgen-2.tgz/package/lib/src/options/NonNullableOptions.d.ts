export declare class NonNullableOptions {
    constructor(filePath?: string);
    private readonly interfaces;
    isNonNullableParameter(iface: string, method: string, parameter: string): boolean;
    isNonNullableReturnType(iface: string, method: string): boolean;
    private isNonNullable;
}
//# sourceMappingURL=NonNullableOptions.d.ts.map