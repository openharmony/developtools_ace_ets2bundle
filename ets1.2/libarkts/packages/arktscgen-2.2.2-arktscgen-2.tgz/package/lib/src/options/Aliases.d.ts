export declare class Aliases {
    constructor(filePath?: string);
    readonly classes: string[];
    readonly functions: string[];
}
//# sourceMappingURL=Aliases.d.ts.map