type CliOptions = {
    pandaSdkPath: string;
    outputDir: string;
    optionsFile: string;
    debug: boolean;
};
export declare function cliOptions(): CliOptions;
export {};
//# sourceMappingURL=cli-options.d.ts.map