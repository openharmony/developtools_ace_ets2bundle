import { BaseInterfaceFilterTransformer } from "./BaseInterfaceFilterTransformer.js";
import { Config } from "../../../general/Config.js";
import { IDLFile, IDLInterface } from "@idlizer/core";
export declare class OptionsFilterTransformer extends BaseInterfaceFilterTransformer {
    private config;
    constructor(config: Config, file: IDLFile);
    protected shouldFilterOutInterface(entry: IDLInterface): boolean;
    protected shouldFilterOutMethod(node: string, name: string): boolean;
    protected shouldFilterOutProperty(node: string, name: string): boolean;
}
//# sourceMappingURL=OptionsFilterTransformer.d.ts.map