import { IDLEntry, IDLFile, IDLInterface } from "@idlizer/core";
export declare abstract class Transformer {
    protected file: IDLFile;
    private removeNamespaces;
    constructor(file: IDLFile, removeNamespaces?: boolean);
    transformFile(input: IDLFile): IDLFile;
    transformDeep(entry: IDLEntry): IDLEntry | undefined;
    transform(entry: IDLEntry): IDLEntry | undefined;
    transformed(): IDLFile;
    abstract transformInterface(entry: IDLInterface): IDLEntry | undefined;
}
//# sourceMappingURL=Transformer.d.ts.map