import { IDLEntry, IDLFile, IDLInterface, IDLMethod } from "@idlizer/core";
import { Transformer } from "../../Transformer.js";
import { Typechecker } from "../../../general/Typechecker.js";
export declare abstract class BaseInterfaceFilterTransformer extends Transformer {
    constructor(file: IDLFile, removeNamespaces?: boolean);
    protected typechecker: Typechecker;
    transformInterface(entry: IDLInterface): IDLEntry | undefined;
    protected abstract shouldFilterOutMethod(node: string, name: string): boolean;
    protected abstract shouldFilterOutProperty(node: string, name: string): boolean;
    protected abstract shouldFilterOutInterface(entry: IDLInterface): boolean;
    protected isReferringForbiddenOrMissing(node: IDLMethod, predicate: (_: IDLInterface) => boolean): boolean;
}
//# sourceMappingURL=BaseInterfaceFilterTransformer.d.ts.map