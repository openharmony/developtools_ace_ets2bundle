import { IgnoreOptions, IrHackOptions } from "../options/IgnoreOptions.js";
import { NonNullableOptions } from "../options/NonNullableOptions.js";
import { CodeFragmentOptions } from "../options/CodeFragmentOptions.js";
import { ExtraParameters } from "../options/ExtraParameters.js";
import { Aliases } from "../options/Aliases.js";
export declare class Config {
    ignore: IgnoreOptions;
    nonNullable: NonNullableOptions;
    irHack: IrHackOptions;
    fragments: CodeFragmentOptions;
    parameters: ExtraParameters;
    aliases: Aliases;
    constructor(ignore: IgnoreOptions, nonNullable: NonNullableOptions, irHack: IrHackOptions, fragments: CodeFragmentOptions, parameters: ExtraParameters, aliases: Aliases);
    static get createPrefix(): string;
    static get updatePrefix(): string;
    static get constPostfix(): string;
    static get ptrPostfix(): string;
    static get nodeTypeAttribute(): string;
    static get nodeNamespaceAttribute(): string;
    static get uselessPrefix(): string;
    static get astNodeCommonAncestor(): string;
    static get astTypeAncestor(): string;
    static get context(): string;
    static get dataClassPrefix(): string;
    static get defaultAncestor(): string;
    static get irNamespace(): string;
}
//# sourceMappingURL=Config.d.ts.map