import { IDLFile, IDLInterface, IDLMethod, IDLNamedNode, IDLNode, IDLReferenceType, IDLType } from "@idlizer/core";
export declare class Typechecker {
    private file;
    private namespaces;
    constructor(file: IDLFile);
    resolveReference(ref: IDLReferenceType): IDLNamedNode | undefined;
    private resolveReference2;
    resolveRecursive(ref: IDLReferenceType): IDLNamedNode | undefined;
    flatParents(ref: IDLReferenceType | IDLInterface): IDLInterface[];
    isHeir(ref: IDLReferenceType | IDLInterface, ancestor: string): boolean;
    hasDescendants(ref: IDLReferenceType | IDLInterface): boolean;
    isPeer(node: IDLInterface | IDLReferenceType): boolean;
    isReferenceTo(type: IDLType, isTarget: (type: IDLNode) => boolean): boolean;
    isConstReturnValue(node: IDLMethod): boolean;
    nodeTypeName(node: IDLInterface): string | undefined;
}
//# sourceMappingURL=Typechecker.d.ts.map