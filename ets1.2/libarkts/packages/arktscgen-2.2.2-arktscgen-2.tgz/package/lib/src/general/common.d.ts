import { IDLInterface, IDLMethod, IDLParameter } from "@idlizer/core";
export declare function peerMethod(name: string): string;
export declare function makeMethodName(name: string): string;
export declare function splitCreateOrUpdate(fullName: string): {
    createOrUpdate: string;
    rest: string;
};
export declare function mangleIfKeyword(name: string): string;
export declare function isContext(param: IDLParameter): boolean;
export declare function isGetter(node: IDLMethod): boolean;
export declare function isRegular(node: IDLMethod): boolean;
export declare function isAbstract(node: IDLInterface): boolean;
export declare function isReal(node: IDLInterface): boolean;
export declare function isDataClass(node: IDLInterface): boolean;
export declare function isCreate(name: string): boolean;
export declare function isCreateOrUpdate(sourceMethodName: string): boolean;
export declare function isImplInterface(name: string): boolean;
export declare function fixEnumPrefix(name: string): string;
//# sourceMappingURL=common.d.ts.map