import * as core from "@idlizer/core";
export declare class CoverageStat {
    total(iface: core.IDLInterface): void;
    ignored(iface: core.IDLInterface): void;
    funcTotal(iface: core.IDLInterface, num?: number): void;
    funcIgnored(iface: core.IDLInterface, num?: number): void;
    dump(): void;
    private makeEntry;
    private stats;
}
export declare var gCoverage: CoverageStat;
//# sourceMappingURL=Coverage.d.ts.map