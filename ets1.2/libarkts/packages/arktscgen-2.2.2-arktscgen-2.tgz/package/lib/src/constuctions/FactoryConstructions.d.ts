export declare class FactoryConstructions {
    static isSame(first: string, second: string): string;
    static all(checks: string[]): string;
    static get original(): string;
    static get updateNodeByNode(): string;
    static get prologue(): string;
    static get epilogue(): string;
}
//# sourceMappingURL=FactoryConstructions.d.ts.map