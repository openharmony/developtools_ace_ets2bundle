import { IDLPrimitiveType } from "@idlizer/core";
export declare class InteropConstructions {
    static get receiver(): string;
    static context: {
        type: import("@idlizer/core").IDLReferenceType;
        name: string;
    };
    static get sequencePointerType(): IDLPrimitiveType;
    static get sequenceLengthType(): IDLPrimitiveType;
    static sequenceParameterPointer(parameter: string): string;
    static sequenceParameterLength(parameter: string): string;
    static method(interfaceName: string, methodName: string, namespaceName?: string): string;
    static get keywords(): string[];
}
//# sourceMappingURL=InteropConstructions.d.ts.map