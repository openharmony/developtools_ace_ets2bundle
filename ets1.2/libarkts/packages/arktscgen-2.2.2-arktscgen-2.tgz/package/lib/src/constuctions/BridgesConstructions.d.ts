export declare class BridgesConstructions {
    static castedParameter(name: string): string;
    static interopMacro(isVoid: boolean, parametersCount: number): string;
    static implFunction(name: string): string;
    static referenceType(name: string): string;
    static get sequenceLengthDeclaration(): string;
    static get sequenceLengthPass(): string;
    static get sequenceLengthUsage(): string;
    static get result(): string;
    static stringConstructor(name: string): string;
    static sequenceConstructor(first: string, length: string): string;
    static referenceTypeCast(type: string): string;
    static primitiveTypeCast(type: string): string;
    static enumCast(type: string): string;
    static callMethod(name: string): string;
    static get stringType(): string;
    static get pointerType(): string;
    static get stringCast(): string;
    static get stringArrayCast(): string;
    static dropConstCast(value: string): string;
    static get astNode(): string;
    static arrayOf(type: string): string;
    static pointer(type: string): string;
}
//# sourceMappingURL=BridgesConstructions.d.ts.map