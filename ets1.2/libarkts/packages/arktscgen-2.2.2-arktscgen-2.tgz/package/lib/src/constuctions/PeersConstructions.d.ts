export declare class PeersConstructions {
    static peerName(name: string): string;
    static fileName(node: string): string;
    static get pointerParameter(): string;
    static get super(): string;
    static get this(): {
        type: import("@idlizer/core").IDLReferenceType;
        name: string;
    };
    static get typeGuard(): {
        name: (type: string) => string;
        parameter: {
            name: string;
            type: string;
        };
        returnType: (type: string) => string;
        body: (type: string) => string;
    };
    static get unpackNullableNode(): string;
    static get unpackNullableConstructable(): string;
    static get unpackNonNullable(): string;
    static get arrayOfPointersToArrayOfPeers(): string;
    static get arrayOfPointersToArrayOfObjects(): string;
    static get receiveString(): string;
    static passNode(name: string): string;
    static passStringArray(name: string): string;
    static passNodeArray(name: string): string;
    static arrayLength(name: string): string;
    static get context(): string;
    static get pointerUsage(): string;
    static callBinding(iface: string, method: string): string;
    static get warn(): string;
    static stubNodeMessage(node: string): string;
    static import(what: string, from: string): string;
    static createOrUpdate(iface: string, method: string): string;
    static universalCreate(iface: string): string;
    static universalUpdate(iface: string): string;
    static get setChildrenParentPtrMethod(): string;
    static newOf(iface: string): string;
    static callPeerMethod(iface: string, method: string): string;
    static brand(iface: string): string;
}
//# sourceMappingURL=PeersConstructions.d.ts.map