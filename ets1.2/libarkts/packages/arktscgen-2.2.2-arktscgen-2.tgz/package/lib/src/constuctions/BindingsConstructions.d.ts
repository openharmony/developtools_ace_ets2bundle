export declare class BindingsConstructions {
    static method(name: string): string;
    static get unimplemented(): string;
    static get class(): string;
}
//# sourceMappingURL=BindingsConstructions.d.ts.map